<?php 

    $con = new mysqli("localhost","root","","sampledb");


?>