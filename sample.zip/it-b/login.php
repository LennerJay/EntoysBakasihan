<?php 
    session_start();  
    if(isset($_SESSION['userid'])){
        header('location:index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <title>Login</title>
    <style>
        .form-control{
            margin-bottom:10px;
        }
    </style>
</head>
<body>
    <div class="container" id="login-app" style="margin-top:50px;">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                        <h2>Log In</h2>
                        
                            <form @submit="login($event)">
                                <div class="col-md-12">
                                <input type="text" class="form-control" placeholder="Username" name="username" /></div>
                            <div class="col-md-12"><input type="password" class="form-control" placeholder="Password" name="password" /></div>
                            <div class="col-md-12"><input type="submit" class="btn btn-success" value="Login" /></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</body>
<script src="assets/js/axios.js"></script>
<script src="assets/js/vue.3.js"></script>
<script>

const { createApp } = Vue;

createApp({
    methods:{
        login:function(e){
            e.preventDefault();

            const data = new FormData(e.currentTarget);
            data.append("method","login");
            axios.post('includes/model.php',data)
            .then(function(r){
                //alert(r.data);
                if(r.data == 1){
                    alert(r.data);
                    window.location.href ="index.php";
                }
                else if(r.data == 2){
                    alert("Account is locked");
                }
                else{
                    alert("Username or password is incorrect");
                }
            })
        }
    },
    mounted:function(){
    }
}).mount('#login-app');

</script>
</html>